
 export const data = [
    {
        "_id": "66f4f4033dd2206729191206",
        "chapterId": "66e9ae1b35760db58e1df2a7",
        "createdAt": "2024-09-26T05:41:23.082Z",
        "duration": 0,
        "questionRandom": "",
        "questions": [
          
        ],
        "status": 0,
        "videoDescription": "<p>fsdhbj</p>",
        "videoResources": [
          "https://imageuploads.blr1.digitaloceanspaces.com/DLVBC_instructor/education-66f4f3fe3dd2206729191205-SBIN_2024-09-20_16-08-41.png"
        ],
        "videoThumbnail": "https://imageuploads.blr1.digitaloceanspaces.com/DLVBC_instructor/education-66f4f3ee3dd2206729191203-SBIN_2024-09-20_16-08-41.png",
        "videoTitle": "test",
        "videoType": "trackable",
        "videoUrl": "https://imageuploads.blr1.digitaloceanspaces.com/DLVBC_instructor/education-66f4f3f43dd2206729191204-file_example_MP4_480_1_5MG.mp4",
        "question": [
          {
            "_id": "66f4f3773dd2206729191202",
            "answer": "1,3",
            "askForExplaination": "false",
            "correct": "1",
            "createdAt": "2024-09-26T05:39:03.326Z",
            "explainationType": "system",
            "incorrect": "0",
            "meta": {
              "chapterTags": [
                
              ],
              "questionTags": [
                "fds"
              ],
              "timeToCompleteQuestion": "60",
              "timeToShowQuestion": 14.149087,
              "videoDuration": 30.526667
            },
            "options": [
              {
                "image": "",
                "text": "<p>fsdfd</p>"
              },
              {
                "image": "",
                "text": "<p>rfsfd</p>"
              },
              {
                "image": "",
                "text": "<p>fgssf</p>"
              }
            ],
            "question": {
              "image": "",
              "text": "<p>fsfsd</p>"
            },
            "questionLevel": "hard",
            "questionType": "mcq",
            "status": 0,
            "videoId": "66e9af2335760db58e1df2b0"
          },
          {
            "_id": "66f4f3343dd2206729191201",
            "answer": "<p>refj</p>,<p>fgdkj</p>",
            "askForExplaination": "false",
            "correct": "1",
            "createdAt": "2024-09-26T05:37:56.753Z",
            "explainationType": "system",
            "fill": {
              "box": "2",
              "type": "multiple"
            },
            "incorrect": "0",
            "meta": {
              "chapterTags": [
                
              ],
              "questionTags": [
                "sdf"
              ],
              "timeToCompleteQuestion": "30",
              "timeToShowQuestion": 14.304839,
              "videoDuration": 30.526667
            },
            "question": {
              "image": "",
              "text": "<p>dfzghj</p>"
            },
            "questionLevel": "easy",
            "questionType": "fillInTheBlanks",
            "status": 0,
            "videoId": "66e9af2335760db58e1df2b0"
          },
          {
            "_id": "66e9b5f435760db58e1df2b7",
            "answer": "2",
            "askForExplaination": "false",
            "correct": "1",
            "createdAt": "2024-09-17T17:01:40.476Z",
            "explainationType": "system",
            "incorrect": "0",
            "meta": {
              "timeToCompleteQuestion": "60",
              "timeToShowQuestion": 15.63723,
              "videoDuration": 0
            },
            "options": [
              {
                "image": "",
                "text": "<p>A</p>"
              },
              {
                "image": "",
                "text": "<p>B</p>"
              }
            ],
            "question": {
              "image": "",
              "text": "<p>hfvg</p>"
            },
            "questionLevel": "easy",
            "questionType": "scq",
            "status": 0,
            "videoId": "66e9af2335760db58e1df2b0"
          },
          {
            "_id": "66e9af6d35760db58e1df2b2",
            "answer": "2",
            "askForExplaination": "false",
            "correct": "1",
            "createdAt": "2024-09-17T16:33:49.302Z",
            "explainationType": "system",
            "incorrect": "0",
            "meta": {
              "timeToCompleteQuestion": "29",
              "timeToShowQuestion": 16.002645,
              "videoDuration": 30.526667
            },
            "options": [
              {
                "image": "",
                "text": "<p>A</p>"
              },
              {
                "image": "",
                "text": "<p>B</p>"
              },
              {
                "image": "",
                "text": "<p>C</p>"
              }
            ],
            "question": {
              "image": "https://imageuploads.blr1.digitaloceanspaces.com/DLVBC_instructor/education-66e9af4635760db58e1df2b1-BANK OF BARODA_Thu 12 Sep '24_22-34-29.png",
              "text": "<p>fshjdb</p>"
            },
            "questionLevel": "hard",
            "questionType": "scq",
            "status": 0,
            "videoId": "66e9af2335760db58e1df2b0"
          }
        ]
      }
]